# MySnapJob

Premium job discovery platform connecting users with verified opportunities from globally recognized brands.

## Deploy to Vercel

### Option 1 — Vercel CLI (fastest)
```bash
npm i -g vercel
vercel
```
Follow the prompts. Your site will be live in ~30 seconds.

### Option 2 — Vercel Dashboard (no CLI)
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **"Add New Project"**
3. Click **"Upload"** (or drag this folder)
4. Click **Deploy**

### Option 3 — GitHub
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo
4. Click **Deploy**

## Local Preview
```bash
npx serve .
```
Then open http://localhost:3000
